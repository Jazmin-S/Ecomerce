package modelo.dao;

import java.util.List;
import modelo.beans.Ventas;
import modelo.sql.MySQLConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class VentasDAO {

    public static List<Ventas> getVentas() {
        List<Ventas> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM ventas;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int folio = rs.getInt("Folio");
                        int idPago = rs.getInt("idPago");
                        int idOrden = rs.getInt("idOrden");
                        Date fecha = rs.getDate("fecha");
                        lista.add(new Ventas(folio, idPago, idOrden, fecha));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public static List<Ventas> buscarPorFolio(int folioBusqueda) {
        List<Ventas> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM ventas WHERE Folio = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, folioBusqueda);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int folio = rs.getInt("Folio");
                        int idPago = rs.getInt("idPago");
                        int idOrden = rs.getInt("idOrden");
                        Date fecha = rs.getDate("fecha");
                        lista.add(new Ventas(folio, idPago, idOrden, fecha));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public static boolean registrar(Ventas venta) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "INSERT INTO ventas (idPago, idOrden, fecha) VALUES (?, ?, ?);";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, venta.getIdPago());
                ps.setInt(2, venta.getIdOrden());
                ps.setDate(3, new java.sql.Date(venta.getFecha().getTime()));               
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean actualizar(Ventas venta) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "UPDATE ventas SET idPago = ?, idOrden = ?, fecha = ? WHERE Folio = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, venta.getIdPago());
                ps.setInt(2, venta.getIdOrden());
                ps.setDate(3, new java.sql.Date(venta.getFecha().getTime()));               
                ps.setInt(4, venta.getFolio());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean eliminar(int folio) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "DELETE FROM ventas WHERE Folio = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, folio);
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
