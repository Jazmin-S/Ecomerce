package modelo.dao;

import java.util.List;
import modelo.beans.Platillo;
import modelo.sql.MySQLConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlatilloDAO {

    public static List<Platillo> getPlatillos() {
        List<Platillo> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM platillo;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idPlatillo = rs.getInt("idPlatillo");
                        String nombre = rs.getString("nombre");
                        float precio = rs.getFloat("precio");
                        String descripcion = rs.getString("Descripcion");
                        String modoPreparacion = rs.getString("modoPreparacion");
                        String tiempoPreparacion = rs.getString("tiempoPreparacion");
                        String tipoPlatillo = rs.getString("tipoPlatillo");
                        lista.add(new Platillo(idPlatillo, nombre, precio, descripcion, modoPreparacion, tiempoPreparacion, tipoPlatillo));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public static List<Platillo> buscarPorNombre(String nombreBusqueda) {
        List<Platillo> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM platillo WHERE nombre LIKE ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setString(1, nombreBusqueda);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idPlatillo = rs.getInt("idPlatillo");
                        String nombre = rs.getString("nombre");
                        float precio = rs.getFloat("precio");
                        String descripcion = rs.getString("Descripcion");
                        String modoPreparacion = rs.getString("modoPreparacion");
                        String tiempoPreparacion = rs.getString("tiempoPreparacion");
                        String tipoPlatillo = rs.getString("tipoPlatillo");
                        lista.add(new Platillo(idPlatillo, nombre, precio, descripcion, modoPreparacion, tiempoPreparacion, tipoPlatillo));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public static boolean registrar(Platillo platillo) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "INSERT INTO platillo (nombre, precio, Descripcion, modoPreparacion, tiempoPreparacion, tipoPlatillo) VALUES (?, ?, ?, ?, ?, ?);";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setString(1, platillo.getNombre());
                ps.setFloat(2, platillo.getPrecio());
                ps.setString(3, platillo.getDescripcion());
                ps.setString(4, platillo.getModoPreparacion());
                ps.setString(5, platillo.getTiempoPreparacion());
                ps.setString(6, platillo.getTipoPlatillo());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean actualizar(Platillo platillo) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "UPDATE platillo SET nombre = ?, precio = ?, Descripcion = ?, modoPreparacion = ?, tiempoPreparacion = ?, tipoPlatillo = ? WHERE idPlatillo = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setString(1, platillo.getNombre());
                ps.setFloat(2, platillo.getPrecio());
                ps.setString(3, platillo.getDescripcion());
                ps.setString(4, platillo.getModoPreparacion());
                ps.setString(5, platillo.getTiempoPreparacion());
                ps.setString(6, platillo.getTipoPlatillo());
                ps.setInt(7, platillo.getIdPlatillo());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean eliminar(int idPlatillo) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "DELETE FROM platillo WHERE idPlatillo = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, idPlatillo);
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
