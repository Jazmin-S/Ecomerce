package modelo.dao;

import java.util.List;
import modelo.beans.Pago;
import modelo.sql.MySQLConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class PagoDAO {

    public static List<Pago> getPagos() {
        List<Pago> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM pago;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idPago = rs.getInt("idPago");
                        float monto = rs.getFloat("Monto");
                        Date fecha = rs.getDate("Fecha");
                        String tipoPago = rs.getString("tipoPago");
                        lista.add(new Pago(idPago, monto, fecha, tipoPago));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public static List<Pago> buscarPorTipoPago(String tipoPagoBusqueda) {
        List<Pago> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM pago WHERE tipoPago LIKE ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setString(1, "%" + tipoPagoBusqueda + "%");
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idPago = rs.getInt("idPago");
                        float monto = rs.getFloat("Monto");
                        Date fecha = rs.getDate("Fecha");
                        String tipoPago = rs.getString("tipoPago");
                        lista.add(new Pago(idPago, monto, fecha, tipoPago));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public static boolean registrar(Pago pago) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "INSERT INTO pago (Monto, Fecha, tipoPago) VALUES (?, ?, ?);";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setFloat(1, pago.getMonto());
                ps.setDate(2, new java.sql.Date(pago.getFecha().getTime()));
                ps.setString(3, pago.getTipoPago());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    
    public static boolean actualizar(Pago pago) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "UPDATE pago SET Monto = ?, Fecha = ?, tipoPago = ? WHERE idPago = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setFloat(1, pago.getMonto());
                ps.setDate(2, new java.sql.Date(pago.getFecha().getTime()));
                ps.setString(3, pago.getTipoPago());
                ps.setInt(4, pago.getIdPago());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    
    public static boolean eliminar(int idPago) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "DELETE FROM pago WHERE idPago = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, idPago);
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}