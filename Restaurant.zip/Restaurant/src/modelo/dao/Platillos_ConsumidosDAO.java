package modelo.dao;

import java.util.List;
import modelo.beans.Platillos_Consumidos;
import modelo.sql.MySQLConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Platillos_ConsumidosDAO {

    public static List<Platillos_Consumidos> getPlatillosConsumidos() {
        List<Platillos_Consumidos> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM platillos_consumidos;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int folioVenta = rs.getInt("FolioVenta");
                        int idPlatillo = rs.getInt("idPlatillo");
                        int cantidad = rs.getInt("cantidad");
                        lista.add(new Platillos_Consumidos(folioVenta, idPlatillo, cantidad));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public static List<Platillos_Consumidos> buscarPorFolioVenta(int folioVenta) {
        List<Platillos_Consumidos> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM platillos_consumidos WHERE FolioVenta = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, folioVenta);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idPlatillo = rs.getInt("idPlatillo");
                        int cantidad = rs.getInt("cantidad");
                        lista.add(new Platillos_Consumidos(folioVenta, idPlatillo, cantidad));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public static boolean registrar(Platillos_Consumidos platilloConsumido) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "INSERT INTO platillos_consumidos (FolioVenta, idPlatillo, cantidad) VALUES (?, ?, ?);";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, platilloConsumido.getFolioVenta());
                ps.setInt(2, platilloConsumido.getIdPlatillo());
                ps.setInt(3, platilloConsumido.getCantidad());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean actualizar(Platillos_Consumidos platilloConsumido) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "UPDATE platillos_consumidos SET cantidad = ? WHERE FolioVenta = ? AND idPlatillo = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, platilloConsumido.getCantidad());
                ps.setInt(2, platilloConsumido.getFolioVenta());
                ps.setInt(3, platilloConsumido.getIdPlatillo());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean eliminar(int folioVenta, int idPlatillo) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "DELETE FROM platillos_consumidos WHERE FolioVenta = ? AND idPlatillo = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, folioVenta);
                ps.setInt(2, idPlatillo);
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
