package modelo.dao;

import java.util.List;
import modelo.beans.Orden;
import modelo.sql.MySQLConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrdenDAO {

    public static List<Orden> getOrdenes() {
        List<Orden> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM orden;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idOrden = rs.getInt("idOrden");
                        int idMesero = rs.getInt("idMesero");
                        int numMesa = rs.getInt("numMesa");
                        String fechaHora = rs.getString("Fecha_hora");
                        lista.add(new Orden(idOrden, idMesero, numMesa, fechaHora));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public static List<Orden> buscarPorNumMesa(int numMesa) {
        List<Orden> lista = new ArrayList<>();
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = new MySQLConnect();
            String query = "SELECT * FROM orden WHERE numMesa = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, numMesa);
                rs = ps.executeQuery();
                if (rs != null) {
                    while (rs.next()) {
                        int idOrden = rs.getInt("idOrden");
                        int idMesero = rs.getInt("idMesero");
                        int numMesaResult = rs.getInt("numMesa");
                        String fechaHora = rs.getString("Fecha_hora");
                        lista.add(new Orden(idOrden, idMesero, numMesaResult, fechaHora));
                    }
                } else {
                    System.out.println("ResultSet null...");
                }
                rs.close();
                ps.close();
                conn.close();
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public static boolean registrar(Orden orden) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "INSERT INTO orden (idMesero, numMesa, Fecha_hora) VALUES (?, ?, ?);";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, orden.getIdMesero());
                ps.setInt(2, orden.getNumMesa());
                ps.setString(3, orden.getFechaHora());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean actualizar(Orden orden) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "UPDATE orden SET idMesero = ?, numMesa = ?, Fecha_hora = ? WHERE idOrden = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, orden.getIdMesero());
                ps.setInt(2, orden.getNumMesa());
                ps.setString(3, orden.getFechaHora());
                ps.setInt(4, orden.getIdOrden());
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean eliminar(int idOrden) {
        MySQLConnect conn = null;
        PreparedStatement ps = null;
        try {
            conn = new MySQLConnect();
            String query = "DELETE FROM orden WHERE idOrden = ?;";
            if (conn != null) {
                ps = conn.connection().prepareStatement(query);
                ps.setInt(1, idOrden);
                ps.executeUpdate();
                ps.close();
                conn.close();
                return true;
            } else {
                System.out.println("Error de conexión");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
