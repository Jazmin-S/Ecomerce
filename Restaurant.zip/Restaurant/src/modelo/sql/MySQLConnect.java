package modelo.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Frost
 */
public class MySQLConnect {

    private Connection conn;
    private String host = "localhost";
    private String port = "3306";
    private String db = "restaurant";
    private String username = "root";
    private String password = "12345";

    private static MySQLConnect connect;

    public MySQLConnect() {
        //String driver = "com.mysql.jdbc.Driver"; Versiones < 8 MySQL
        //String url = "jdbc:mysql://" + host + ":"+port+"/" + db;
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://" + host + ":"+port+"/" + db + "?useTimezone=true&serverTimezone=UTC";
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        connect = this;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getDb() {
        return db;
    }

    public void setDb(String db) {
        this.db = db;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Connection connection() {
        return conn;
    }

    public Statement query(String sQuery) throws SQLException {
        Statement s = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        s.executeQuery(sQuery);
        return s;
    }

    public Statement update(String sQuery) throws SQLException {
        Statement s = conn.createStatement();
        s.executeUpdate(sQuery);
        return s;
    }

    public void close(Statement s) {
        try {
            s.close();
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage() + "\n" +
                    e.getErrorCode());
        }
    }

    public void close() {
        try {
            if(conn!=null){
                conn.close();   
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage() + "\n" + e.getErrorCode());
        }
    }

    public static MySQLConnect getConnect() {
        return connect;
    }

    public static void setConnect(MySQLConnect connect) {
        MySQLConnect.connect = connect;
    }
}
