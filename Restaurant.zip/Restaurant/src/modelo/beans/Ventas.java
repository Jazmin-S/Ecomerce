package modelo.beans;

/**
 *
 * @author gaelr
 */
import java.time.LocalDate;
import java.util.Date;

public class Ventas {
    private int folio;
    private int idPago;
    private int idOrden;
    private Date fecha;

    public Ventas() {}

    public Ventas(int folio, int idPago, int idOrden, Date fecha) {
        this.folio = folio;
        this.idPago = idPago;
        this.idOrden = idOrden;
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Ventas{" + "folio=" + folio + ", idPago=" + idPago + ", idOrden=" + idOrden + ", fecha=" + fecha + '}';
    }

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
}