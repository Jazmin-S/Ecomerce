package modelo.beans;

/**
 *
 * @author gaelr
 */
public class Mesero {
    private Integer idMesero;
    private String nombre;
    private String apellidos;
    
    public Mesero(){
    }

    public Mesero(Integer idMesero, String nombre, String apellidos) {
        this.idMesero = idMesero;
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    @Override
    public String toString() {
        return "Mesero{" + "idMesero=" + idMesero + ", nombre=" + nombre + ", apellidos=" + apellidos + '}';
    }

    public Integer getIdMesero() {
        return idMesero;
    }

    public void setIdMesero(Integer idMesero) {
        this.idMesero = idMesero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
       
}