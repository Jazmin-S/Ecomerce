package modelo.beans;

/**
 *
 * @author gaelr
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Orden {
    private int idOrden;
    private int idMesero;
    private int numMesa;
    private String fechaHora;

    public Orden() {
    }

    public Orden(int idOrden, int idMesero, int numMesa, String fechaHora) {
        this.idOrden = idOrden;
        this.idMesero = idMesero;
        this.numMesa = numMesa;
        this.fechaHora = fechaHora;
    }

    @Override
    public String toString() {
        return "Orden{" + "idOrden=" + idOrden + ", idMesero=" + idMesero + ", numMesa=" + numMesa + ", fechaHora=" + fechaHora + '}';
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getIdMesero() {
        return idMesero;
    }

    public void setIdMesero(int idMesero) {
        this.idMesero = idMesero;
    }

    public int getNumMesa() {
        return numMesa;
    }

    public void setNumMesa(int numMesa) {
        this.numMesa = numMesa;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public Calendar obtenerFechaHora() {
        SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
        Calendar calendar = Calendar.getInstance();
        try {
            Date date = sdf.parse(this.fechaHora);
            calendar.setTime(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return calendar;
    }
}
