package modelo.beans;

/**
 *
 * @author gaelr
 */
public class Platillos_Consumidos {
    private int folioVenta;
    private int idPlatillo;
    private int cantidad;

    public Platillos_Consumidos() {}

    public Platillos_Consumidos(int folioVenta, int idPlatillo, int cantidad) {
        this.folioVenta = folioVenta;
        this.idPlatillo = idPlatillo;
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "PlatillosConsumidos{" + "folioVenta=" + folioVenta + ", idPlatillo=" + idPlatillo + ", cantidad=" + cantidad + '}';
    }

    public int getFolioVenta() {
        return folioVenta;
    }

    public void setFolioVenta(int folioVenta) {
        this.folioVenta = folioVenta;
    }

    public int getIdPlatillo() {
        return idPlatillo;
    }

    public void setIdPlatillo(int idPlatillo) {
        this.idPlatillo = idPlatillo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
}