package modelo.beans;

/**
 *
 * @author gaelr
 */
public class Platillo {
    private int idPlatillo;
    private String nombre;
    private float precio;
    private String descripcion;
    private String modoPreparacion;
    private String tiempoPreparacion;
    private String tipoPlatillo;

    public Platillo(){
    }

    public Platillo(int idPlatillo, String nombre, float precio, String descripcion, String modoPreparacion, String tiempoPreparacion, String tipoPlatillo) {
        this.idPlatillo = idPlatillo;
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.modoPreparacion = modoPreparacion;
        this.tiempoPreparacion = tiempoPreparacion;
        this.tipoPlatillo = tipoPlatillo;
    }

    @Override
    public String toString() {
        return "Platillo{" + "idPlatillo=" + idPlatillo + ", nombre=" + nombre + ", precio=" + precio + ", descripcion=" + descripcion + ", modoPreparacion=" + modoPreparacion + ", tiempoPreparacion=" + tiempoPreparacion + ", tipoPlatillo=" + tipoPlatillo + '}';
    }

    public int getIdPlatillo() {
        return idPlatillo;
    }

    public void setIdPlatillo(int idPlatillo) {
        this.idPlatillo = idPlatillo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getModoPreparacion() {
        return modoPreparacion;
    }

    public void setModoPreparacion(String modoPreparacion) {
        this.modoPreparacion = modoPreparacion;
    }

    public String getTiempoPreparacion() {
        return tiempoPreparacion;
    }

    public void setTiempoPreparacion(String tiempoPreparacion) {
        this.tiempoPreparacion = tiempoPreparacion;
    }

    public String getTipoPlatillo() {
        return tipoPlatillo;
    }

    public void setTipoPlatillo(String tipoPlatillo) {
        this.tipoPlatillo = tipoPlatillo;
    }
}
