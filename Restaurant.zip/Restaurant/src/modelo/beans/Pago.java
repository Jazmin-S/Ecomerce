package modelo.beans;

/**
 *
 * @author gaelr
 */
import java.util.Date;

public class Pago {
    private int idPago;
    private float monto;
    private Date fecha;
    private String tipoPago;

    public Pago() {}

    public Pago(int idPago, float monto, Date fecha, String tipoPago) {
        this.idPago = idPago;
        this.monto = monto;
        this.fecha = fecha;
        this.tipoPago = tipoPago;
    }

    @Override
    public String toString() {
        return "Pago{" + "idPago=" + idPago + ", monto=" + monto + ", fecha=" + fecha + ", tipoPago=" + tipoPago + '}';
    }

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }
    
}