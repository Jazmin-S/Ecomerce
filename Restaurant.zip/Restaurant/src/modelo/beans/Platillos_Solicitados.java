package modelo.beans;

/**
 *
 * @author gaelr
 */
public class Platillos_Solicitados{
    private int idOrden;
    private int idPlatillo;
    private int cantidad;

    public Platillos_Solicitados(){
    }

    public Platillos_Solicitados(int idOrden, int idPlatillo, int cantidad) {
        this.idOrden = idOrden;
        this.idPlatillo = idPlatillo;
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Platillos_Solicitados{" + "idOrden=" + idOrden + ", idPlatillo=" + idPlatillo + ", cantidad=" + cantidad + '}';
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getIdPlatillo() {
        return idPlatillo;
    }

    public void setIdPlatillo(int idPlatillo) {
        this.idPlatillo = idPlatillo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }    
}