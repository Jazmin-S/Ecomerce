package restaurant;

import vistas.MeserosView;

/**
 *
 * @author gaelr
 */
public class Restaurant {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new MeserosView().setVisible(true);
    }
    
}
